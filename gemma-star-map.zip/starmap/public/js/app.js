/* Interactive star map: d3-geo stereographic projection on canvas.
 * Hover = nearest star within a pixel radius; click = side panel + Gemma explainer.
 */
(function () {
  "use strict";
  const DEG = Math.PI / 180;
  const HOVER_RADIUS = 14;          // px
  const CLIP_ANGLE = 100;           // deg from view center that is drawn
  const TOUR_DWELL_MS = 10000;
  const params = new URLSearchParams(location.search);

  // ---------- DOM ----------
  const $ = (id) => document.getElementById(id);
  const canvas = $("sky"), ctx = canvas.getContext("2d");
  const tooltip = $("tooltip"), panel = $("panel"), chat = $("chat");
  const askForm = $("ask-form"), askInput = $("ask-input");
  const banner = $("mode-banner");

  // ---------- State ----------
  let stars = [], mw = null, lines = null, conNames = {};
  let W = 0, H = 0, DPR = 1, baseScale = 1;
  let zoom = 1;
  let rotate = [-(+params.get("ra") || 83), -(+params.get("dec") || 5), 0]; // start near Orion
  const show = { lines: true, mw: true, labels: true };
  let hovered = null, selected = null, tourStar = null;
  let screen = null; // Float32Array [x,y,...] for visible stars; NaN when hidden
  let dirty = true;
  const projection = d3.geoStereographic().reflectX(true).clipAngle(CLIP_ANGLE).precision(0.7);
  const path = d3.geoPath(projection, ctx);
  const graticule = d3.geoGraticule().step([15, 10])();

  // ---------- Helpers ----------
  function bvToRgb(bv) {
    // Approximation after Mitchell Charity's blackbody table (B-V -> sRGB).
    if (bv == null || isNaN(bv)) bv = 0.6;
    bv = Math.max(-0.4, Math.min(2.0, bv));
    let r, g, b, t;
    if (bv < 0.0) { t = (bv + 0.4) / 0.4; r = 0.61 + 0.11 * t + 0.1 * t * t; }
    else if (bv < 0.4) { t = bv / 0.4; r = 0.83 + 0.17 * t; }
    else r = 1.0;
    if (bv < 0.0) { t = (bv + 0.4) / 0.4; g = 0.70 + 0.07 * t + 0.1 * t * t; }
    else if (bv < 0.4) { t = bv / 0.4; g = 0.87 + 0.11 * t; }
    else if (bv < 1.6) { t = (bv - 0.4) / 1.2; g = 0.98 - 0.16 * t; }
    else { t = (bv - 1.6) / 0.4; g = 0.82 - 0.5 * t * t; }
    if (bv < 0.4) b = 1.0;
    else if (bv < 1.5) { t = (bv - 0.4) / 1.1; b = 1.0 - 0.47 * t + 0.1 * t * t; }
    else { t = (bv - 1.5) / 0.44; b = 0.63 - 0.6 * t * t; }
    const c = (v) => Math.round(Math.max(0, Math.min(1, v)) * 255);
    return `rgb(${c(r)},${c(g)},${c(b)})`;
  }
  function starRadius(mag) {
    const z = Math.pow(zoom, 0.35);
    return Math.max(0.45, (6.9 - mag) * 0.62) * z;
  }
  function fmtRA(deg) {
    const h = deg / 15, hh = Math.floor(h), m = (h - hh) * 60, mm = Math.floor(m), ss = (m - mm) * 60;
    return `${hh}h ${String(mm).padStart(2, "0")}m ${ss.toFixed(0).padStart(2, "0")}s`;
  }
  function fmtDec(deg) {
    const s = deg < 0 ? "−" : "+", a = Math.abs(deg), d = Math.floor(a), m = (a - d) * 60, mm = Math.floor(m), ss = (m - mm) * 60;
    return `${s}${d}° ${String(mm).padStart(2, "0")}′ ${ss.toFixed(0).padStart(2, "0")}″`;
  }
  function fmtDist(s) {
    return s.dist_ly ? `${s.dist_ly < 100 ? s.dist_ly : Math.round(s.dist_ly).toLocaleString()} ly` : "unknown";
  }
  const SPECT_DESC = {
    O: "blue, extremely hot (>30,000 K)", B: "blue-white, very hot (10,000–30,000 K)", A: "white (7,500–10,000 K)",
    F: "yellow-white (6,000–7,500 K)", G: "yellow, Sun-like (5,200–6,000 K)", K: "orange (3,700–5,200 K)",
    M: "red, cool (2,400–3,700 K)", C: "carbon star (cool, red)", S: "S-type giant (cool)", W: "Wolf-Rayet (very hot)",
  };
  function spectDesc(sp) {
    if (!sp) return "";
    const cls = sp.trim()[0];
    let lum = "";
    if (/Ia|Ib|I(?![IV])/.test(sp) && !/II|IV/.test(sp)) lum = " supergiant";
    else if (/III/.test(sp)) lum = " giant";
    else if (/II/.test(sp)) lum = " bright giant";
    else if (/IV/.test(sp)) lum = " subgiant";
    else if (/V/.test(sp)) lum = " main-sequence";
    return (SPECT_DESC[cls] || "") + lum;
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }
  function center() { return [-rotate[0], -rotate[1]]; }
  function requestRender() { dirty = true; }

  // Payload sent to the backend: the catalog object + constellation full name.
  function starPayload(s) {
    const { id, name, proper, hip, ra, dec, mag, dist_ly, spect, con, ci } = s;
    return { id, name, proper, hip, ra, dec, mag, dist_ly, spect, con, con_name: conNames[con] || con, ci };
  }

  // ---------- Layout ----------
  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth; H = window.innerHeight;
    canvas.width = Math.round(W * DPR); canvas.height = Math.round(H * DPR);
    canvas.style.width = W + "px"; canvas.style.height = H + "px";
    baseScale = Math.max(W, H) * 0.42;
    requestRender();
  }

  // ---------- Render ----------
  function render(now) {
    projection.translate([W / 2, H / 2]).scale(baseScale * zoom).rotate(rotate);
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    // background
    const bg = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, Math.max(W, H) * 0.75);
    bg.addColorStop(0, "#0a1024"); bg.addColorStop(1, "#02030a");
    ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);

    // sky sphere edge
    ctx.beginPath(); path({ type: "Sphere" });
    ctx.fillStyle = "rgba(10,16,40,0.35)"; ctx.fill();

    // Milky Way (5 nested density levels, additive)
    if (show.mw && mw) {
      ctx.save(); ctx.globalCompositeOperation = "lighter";
      mw.features.forEach((f, i) => {
        ctx.beginPath(); path(f);
        ctx.fillStyle = `rgba(${120 + i * 15},${135 + i * 15},${190 + i * 10},${0.06 + i * 0.014})`;
        ctx.fill();
      });
      ctx.restore();
    }

    // graticule
    ctx.beginPath(); path(graticule);
    ctx.strokeStyle = "rgba(120,150,255,0.07)"; ctx.lineWidth = 1; ctx.stroke();

    // constellation lines
    if (show.lines && lines) {
      ctx.beginPath(); path(lines);
      ctx.strokeStyle = "rgba(120,160,255,0.28)"; ctx.lineWidth = 1; ctx.stroke();
    }

    // stars
    const c = center(), cl = Math.cos(c[1] * DEG), sl = Math.sin(c[1] * DEG);
    const cx = cl * Math.cos(c[0] * DEG), cy = cl * Math.sin(c[0] * DEG), cz = sl;
    const cosClip = Math.cos((CLIP_ANGLE - 1) * DEG);
    const magLimit = 5.2 + Math.log2(zoom) * 0.9; // show fainter stars as you zoom in
    for (let i = 0; i < stars.length; i++) {
      const s = stars[i];
      if (s.mag > magLimit || s._x * cx + s._y * cy + s._z * cz < cosClip) { screen[2 * i] = NaN; continue; }
      const p = projection([s.ra, s.dec]);
      const x = p[0], y = p[1];
      if (x < -20 || y < -20 || x > W + 20 || y > H + 20) { screen[2 * i] = NaN; continue; }
      screen[2 * i] = x; screen[2 * i + 1] = y;
      const r = starRadius(s.mag);
      if (s.mag < 2.0) {
        const g = ctx.createRadialGradient(x, y, 0, x, y, r * 4);
        g.addColorStop(0, s._color.replace("rgb", "rgba").replace(")", ",0.55)"));
        g.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 4, 0, 2 * Math.PI); ctx.fill();
      }
      ctx.globalAlpha = s.mag > 5.5 ? 0.6 : 1;
      ctx.fillStyle = s._color; ctx.beginPath(); ctx.arc(x, y, r, 0, 2 * Math.PI); ctx.fill();
      ctx.globalAlpha = 1;
    }

    // labels
    if (show.labels) {
      const labelMag = 1.6 + Math.log2(zoom) * 1.1;
      ctx.font = "11px system-ui, sans-serif"; ctx.fillStyle = "rgba(200,215,255,0.75)"; ctx.textBaseline = "middle";
      for (let i = 0; i < stars.length; i++) {
        const s = stars[i];
        if (!s.proper || s.mag > labelMag || isNaN(screen[2 * i])) continue;
        ctx.fillText(s.name, screen[2 * i] + starRadius(s.mag) + 4, screen[2 * i + 1]);
      }
    }

    // highlight rings
    const pulse = 0.5 + 0.5 * Math.sin((now || 0) / 300);
    drawRing(tourStar, "rgba(255,210,124,", 10 + pulse * 6, 0.9);
    drawRing(selected, "rgba(124,196,255,", 9 + pulse * 3, 0.95);
    drawRing(hovered, "rgba(255,255,255,", 8, 0.9);
  }

  function drawRing(s, rgbaPrefix, extra, alpha) {
    if (!s) return;
    const i = s._i; const x = screen[2 * i], y = screen[2 * i + 1];
    let px = x, py = y;
    if (isNaN(x)) { // star may be below mag limit at this zoom; still project if on the visible side
      const c = center();
      if (d3.geoDistance([s.ra, s.dec], c) > (CLIP_ANGLE - 1) * DEG) return;
      [px, py] = projection([s.ra, s.dec]);
    }
    ctx.beginPath(); ctx.arc(px, py, starRadius(s.mag) + extra, 0, 2 * Math.PI);
    ctx.strokeStyle = rgbaPrefix + alpha + ")"; ctx.lineWidth = 1.6; ctx.stroke();
  }

  function loop(now) {
    if (dirty || selected || tourStar) { render(now); dirty = false; }
    requestAnimationFrame(loop);
  }

  // ---------- Picking ----------
  function pick(mx, my) {
    let best = null, bestScore = Infinity;
    for (let i = 0; i < stars.length; i++) {
      const x = screen[2 * i]; if (isNaN(x)) continue;
      const dx = x - mx, dy = screen[2 * i + 1] - my;
      const d = Math.sqrt(dx * dx + dy * dy);
      if (d > HOVER_RADIUS + starRadius(stars[i].mag)) continue;
      const score = d - (6.5 - stars[i].mag) * 0.9; // prefer brighter stars when close
      if (score < bestScore) { bestScore = score; best = stars[i]; }
    }
    return best;
  }

  function showTooltip(s, mx, my) {
    if (!s) { tooltip.hidden = true; return; }
    tooltip.innerHTML = `<b>${esc(s.name)}</b><br><span class="t-sub">${esc(conNames[s.con] || s.con || "—")} · mag ${s.mag} · ${esc(fmtDist(s))}</span>`;
    tooltip.hidden = false;
    const tw = tooltip.offsetWidth, th = tooltip.offsetHeight;
    let x = mx + 16, y = my + 14;
    if (x + tw > W - 8) x = mx - tw - 16;
    if (y + th > H - 8) y = my - th - 14;
    tooltip.style.left = x + "px"; tooltip.style.top = y + "px";
  }

  // ---------- Interaction ----------
  let drag = null;
  canvas.addEventListener("pointerdown", (e) => {
    drag = { x: e.clientX, y: e.clientY, moved: 0, rot: rotate.slice() };
    canvas.setPointerCapture(e.pointerId);
  });
  canvas.addEventListener("pointermove", (e) => {
    if (drag) {
      const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      drag.moved = Math.max(drag.moved, Math.hypot(dx, dy));
      if (drag.moved > 3) {
        canvas.classList.add("dragging");
        const k = 2 / (baseScale * zoom) / DEG; // stereographic: ~0.5*scale px per radian at center
        rotate = [drag.rot[0] - dx * k, Math.max(-90, Math.min(90, drag.rot[1] - dy * k)), 0];
        hovered = null; tooltip.hidden = true; requestRender();
        return;
      }
    }
    const s = pick(e.clientX, e.clientY);
    if (s !== hovered) { hovered = s; requestRender(); }
    canvas.classList.toggle("over-star", !!s);
    showTooltip(s, e.clientX, e.clientY);
  });
  canvas.addEventListener("pointerup", (e) => {
    const wasClick = drag && drag.moved <= 3;
    drag = null; canvas.classList.remove("dragging");
    if (wasClick) {
      const s = pick(e.clientX, e.clientY);
      if (s) { if (tour.active) tour.pause(true); selectStar(s); }
    }
  });
  canvas.addEventListener("pointerleave", () => { hovered = null; tooltip.hidden = true; requestRender(); });
  canvas.addEventListener("wheel", (e) => {
    e.preventDefault();
    const f = Math.exp(-e.deltaY * 0.0015);
    zoom = Math.max(0.5, Math.min(16, zoom * f));
    requestRender();
  }, { passive: false });
  window.addEventListener("resize", resize);
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { if (tour.active) tour.stop(); else closePanel(); }
  });

  // smooth fly-to
  let flyTimer = null;
  function flyTo(s, ms = 1600, targetZoom) {
    if (flyTimer) flyTimer.stop();
    const r0 = rotate.slice(), z0 = zoom;
    let r1 = [-s.ra, -s.dec, 0];
    // shortest path in longitude
    let d = ((r1[0] - r0[0]) % 360 + 540) % 360 - 180; r1[0] = r0[0] + d;
    const z1 = targetZoom || Math.max(zoom, 1.6);
    const ease = d3.easeCubicInOut;
    return new Promise((resolve) => {
      flyTimer = d3.timer((t) => {
        const k = Math.min(1, t / ms), e = ease(k);
        // gentle zoom-out in the middle of long flights
        const dip = Math.min(1, Math.abs(d) / 90) * Math.sin(Math.PI * e) * 0.35;
        rotate = [r0[0] + (r1[0] - r0[0]) * e, r0[1] + (r1[1] - r0[1]) * e, 0];
        zoom = (z0 + (z1 - z0) * e) * (1 - dip);
        requestRender();
        if (k >= 1) { flyTimer.stop(); flyTimer = null; resolve(); }
      });
    });
  }

  // ---------- Panel ----------
  let reqToken = 0;
  function selectStar(s) {
    selected = s; requestRender();
    $("panel-title").textContent = s.name;
    $("panel-sub").textContent = [s.proper && s.hip ? `HIP ${s.hip}` : null, conNames[s.con] || s.con].filter(Boolean).join(" · ");
    const facts = [
      ["Constellation", esc(conNames[s.con] ? `${conNames[s.con]} (${s.con})` : s.con || "—")],
      ["Apparent mag", s.mag],
      ["Distance", esc(fmtDist(s))],
      ["Spectral type", esc(s.spect || "—") + (spectDesc(s.spect) ? `<br><small style="color:var(--muted)">${esc(spectDesc(s.spect))}</small>` : "")],
      ["Color (B−V)", `<span class="swatch" style="background:${s._color};color:${s._color}"></span>${s.ci ?? "—"}`],
      ["RA / Dec", `${fmtRA(s.ra)}<br>${fmtDec(s.dec)}`],
      ["Catalog", `HYG #${s.id}${s.hip ? ` · HIP ${s.hip}` : ""}`],
    ];
    $("facts").innerHTML = facts.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join("");
    chat.innerHTML = "";
    panel.classList.add("open"); panel.setAttribute("aria-hidden", "false"); document.body.classList.add("panel-open");
    ask(null);
  }
  function closePanel() {
    panel.classList.remove("open"); panel.setAttribute("aria-hidden", "true"); document.body.classList.remove("panel-open");
    selected = null; reqToken++; requestRender();
  }
  $("panel-close").addEventListener("click", closePanel);

  async function ask(question) {
    if (!selected) return;
    const token = ++reqToken, star = selected;
    if (question) chat.insertAdjacentHTML("beforeend", `<div class="msg q">${esc(question)}</div>`);
    const box = document.createElement("div");
    box.className = "msg md loading";
    box.textContent = question ? "Gemma is thinking" : "Asking Gemma about " + star.name;
    chat.appendChild(box); chat.scrollTop = chat.scrollHeight;
    setAskBusy(true);
    try {
      const res = await StarAPI.explain(starPayload(star), question || undefined);
      if (token !== reqToken) return; // user moved on
      box.classList.remove("loading");
      box.innerHTML = renderMarkdown(res.text || "_(No text returned.)_");
    } catch (err) {
      if (token !== reqToken) return;
      box.className = "msg err";
      box.textContent = "Couldn't get an explanation: " + (err.message || err);
    } finally {
      if (token === reqToken) setAskBusy(false);
      chat.scrollTop = chat.scrollHeight;
    }
  }
  function setAskBusy(b) { askInput.disabled = b; askForm.querySelector("button").disabled = b; if (!b) askInput.focus({ preventScroll: true }); }
  askForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const q = askInput.value.trim(); if (!q) return;
    askInput.value = ""; ask(q);
  });

  // ---------- Tour ----------
  const tour = {
    active: false, picks: [], idx: 0, timer: null, paused: false,
    async start() {
      const btn = $("tour-btn");
      btn.disabled = true; btn.textContent = "Planning tour…";
      const candidates = stars.filter((s) => s.proper).slice(0, 40).map(starPayload);
      try {
        const res = await StarAPI.tour(candidates);
        const byId = new Map(stars.map((s) => [String(s.id), s]));
        const byName = new Map(stars.filter((s) => s.proper).map((s) => [s.proper.toLowerCase(), s]));
        this.picks = (res.picks || []).map((p) => {
          const s = byId.get(String(p.id)) || (p.name && byName.get(String(p.name).toLowerCase()));
          return s ? { star: s, blurb: p.blurb || "" } : null;
        }).filter(Boolean);
        if (!this.picks.length) throw new Error("The tour came back empty.");
        this.active = true; this.paused = false; this.idx = 0;
        $("tour-card").hidden = false; $("tour-pause").textContent = "❚❚";
        closePanel();
        this.go(0);
      } catch (err) {
        alert("Couldn't start the tour: " + (err.message || err));
      } finally {
        btn.disabled = false; btn.textContent = "▶ Tour";
      }
    },
    async go(i) {
      clearTimeout(this.timer);
      this.idx = (i + this.picks.length) % this.picks.length;
      const { star, blurb } = this.picks[this.idx];
      tourStar = star;
      $("tour-step").textContent = `Stop ${this.idx + 1} of ${this.picks.length}`;
      $("tour-name").textContent = star.name;
      $("tour-blurb").innerHTML = renderMarkdown(blurb);
      await flyTo(star, 1800, 2.2);
      if (this.active && !this.paused) this.schedule();
    },
    schedule() {
      clearTimeout(this.timer);
      this.timer = setTimeout(() => {
        if (this.idx + 1 >= this.picks.length) this.stop(); else this.go(this.idx + 1);
      }, TOUR_DWELL_MS);
    },
    pause(force) {
      this.paused = force === true ? true : !this.paused;
      $("tour-pause").textContent = this.paused ? "▶" : "❚❚";
      if (this.paused) clearTimeout(this.timer); else this.schedule();
    },
    stop() {
      clearTimeout(this.timer); this.active = false; tourStar = null;
      $("tour-card").hidden = true; requestRender();
    },
  };
  $("tour-btn").addEventListener("click", () => tour.start());
  $("tour-next").addEventListener("click", () => tour.go(tour.idx + 1));
  $("tour-prev").addEventListener("click", () => tour.go(tour.idx - 1));
  $("tour-pause").addEventListener("click", () => tour.pause());
  $("tour-stop").addEventListener("click", () => tour.stop());
  $("tour-name").addEventListener("click", () => { if (tourStar) { tour.pause(true); selectStar(tourStar); } });
  $("tour-name").style.cursor = "pointer"; $("tour-name").title = "Open details";

  // ---------- Toggles & search ----------
  ["lines", "mw", "labels"].forEach((k) => $("toggle-" + k).addEventListener("change", (e) => { show[k] = e.target.checked; requestRender(); }));
  const search = $("search");
  function doSearch() {
    const q = search.value.trim().toLowerCase(); if (!q) return;
    const s = stars.find((x) => x.name.toLowerCase() === q || (x.proper && x.proper.toLowerCase() === q))
      || stars.find((x) => x.name.toLowerCase().startsWith(q))
      || stars.find((x) => x.name.toLowerCase().includes(q) || (x.hip && `hip ${x.hip}` === q));
    if (!s) { search.style.borderColor = "#ff6b6b"; setTimeout(() => (search.style.borderColor = ""), 900); return; }
    search.blur();
    if (tour.active) tour.pause(true);
    flyTo(s, 1400).then(() => selectStar(s));
  }
  search.addEventListener("change", doSearch);
  search.addEventListener("keydown", (e) => { if (e.key === "Enter") doSearch(); });

  function updateBanner() {
    if (StarAPI.state.mock) {
      banner.hidden = false;
      banner.textContent = `Demo mode — showing placeholder text (backend not connected: ${StarAPI.state.reason})`;
    }
  }
  StarAPI.onModeChange(updateBanner);

  // ---------- Boot ----------
  async function boot() {
    resize();
    const [s, m, l, cn] = await Promise.all([
      d3.json("data/stars.json"),
      d3.json("data/mw.json").catch(() => null),
      d3.json("data/constellations.lines.json").catch(() => null),
      d3.json("data/constellation_names.json").catch(() => ({})),
    ]);
    stars = s; mw = m; lines = l; conNames = cn || {};
    stars.forEach((st, i) => {
      st._i = i; st._color = bvToRgb(st.ci);
      const cd = Math.cos(st.dec * DEG);
      st._x = cd * Math.cos(st.ra * DEG); st._y = cd * Math.sin(st.ra * DEG); st._z = Math.sin(st.dec * DEG);
    });
    screen = new Float32Array(stars.length * 2).fill(NaN);
    $("star-names").innerHTML = stars.filter((x) => x.proper).map((x) => `<option value="${esc(x.proper)}">`).join("");
    updateBanner();
    requestRender();
    requestAnimationFrame(loop);
    window.__starmap = {
      ready: true, count: stars.length, stars, selectStar, flyTo, tour,
      project: (st) => projection([st.ra, st.dec]),
      get rotate() { return rotate; }, get zoom() { return zoom; },
    };
  }
  boot().catch((err) => {
    console.error(err);
    document.body.insertAdjacentHTML("beforeend", `<div class="msg err" style="position:fixed;top:60px;left:20px;z-index:20">Failed to load star data: ${esc(err.message || err)}</div>`);
  });
})();

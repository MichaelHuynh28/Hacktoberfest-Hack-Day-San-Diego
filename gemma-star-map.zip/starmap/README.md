# 🌌 Gemma Star Map

An interactive map of the night sky and the Milky Way. Hover over any star to see what it is, then click it and **Gemma 4**, Google's open-weight model, writes a short explainer grounded in real catalog data. You can ask follow-up questions about the star, or press **Tour** and Gemma picks five interesting stars and walks you through them.

> Built in four hours at **Hacktoberfest Hack Day @ UC San Diego** (DS3).

![Screenshot placeholder](docs/screenshot.png)
<!-- TODO: add a screenshot at docs/screenshot.png -->

## How it works

1. **Star data**: we filter the HYG database (around 120k stars) down to the brightest few thousand and ship them as `public/data/stars.json`.
2. **Sky map**: the frontend draws the stars, the Milky Way, and the constellations. On hover it finds the nearest star and shows its name and constellation.
3. **Gemma 4**: on click, the backend sends that star's catalog row (position, magnitude, distance, spectral type, color index) to Gemma 4 through the Gemini API. The prompt tells Gemma to use only those numbers, to avoid making up precise figures, and to say so when it isn't sure. The server also works out the star's brightness compared with the Sun from its magnitude and distance, so Gemma doesn't have to.

```
browser ──hover──▶ local nearest-star lookup
        ──click──▶ POST /api/explain ──▶ Gemma 4 (gemma-4-26b-a4b-it) ──▶ markdown explainer
        ──tour───▶ POST /api/tour    ──▶ Gemma 4 picks 5 stars (JSON)
```

## Open-source and open-weight pieces

| Piece | Role | License |
|---|---|---|
| [Gemma 4](https://ai.google.dev/gemma) (`gemma-4-26b-a4b-it`) | Explanations, Q&A, and tours | Open weights (Gemma license) |
| [HYG Database](https://github.com/astronexus/HYG-Database) by David Nash / astronexus | Star catalog | CC BY-SA 4.0 |
| [D3](https://d3js.org) / [d3-celestial](https://github.com/ofrohn/d3-celestial) | Sky rendering and projections | ISC / BSD-3-Clause |
| [Express](https://expressjs.com) | Backend server | MIT |

**Data attribution:** star data comes from the HYG Database by David Nash (astronexus.com), licensed under [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). The derived `public/data/stars.json` is shared under the same license.

## Setup

Requirements: Node.js 18 or newer.

1. Get a free Gemini API key at [aistudio.google.com](https://aistudio.google.com/apikey).
2. Set up and run:
   ```bash
   git clone <this repo> && cd gemma-star-map
   cp .env.example .env      # then paste your key into GEMINI_API_KEY
   npm install
   npm start
   ```
3. Open <http://localhost:3000>.

Environment variables:

| Var | Default | Notes |
|---|---|---|
| `GEMINI_API_KEY` | (required) | Stays on the server and is never sent to the browser |
| `GEMMA_MODEL` | `gemma-4-26b-a4b-it` | Or `gemma-4-31b-it` |
| `PORT` | `3000` | |

## API

- `GET /api/health` returns `{ ok, model, hasKey }`
- `POST /api/explain` takes `{ star: {id,name,ra,dec,mag,dist_ly,spect,con,ci}, question? }` (ra in degrees, as in stars.json) and returns `{ text }` (markdown)
- `POST /api/tour` takes `{ stars: [...] }` and returns `{ picks: [{ id, blurb }] }`

Responses are cached in memory by star and question. If the key is missing, the server returns `503 {"error": "GEMINI_API_KEY is not set...", "code": "missing_api_key"}`.

## Hackathon challenges

- **Best Open-Source AI Project**: an MIT-licensed public repo, with the open-weight Gemma 4 model at the center of the experience.
- **Best Use of Gemma 4**: every explanation, follow-up answer, and tour comes from Gemma 4 through the Gemini API.

## License

The code is under the [MIT License](LICENSE), © 2026 Michael Huynh. The star data is under CC BY-SA 4.0 (see above).

## Rebuilding the star data

`scripts/build_stars.py` downloads the HYG CSV into `data_raw/`, which git ignores, and regenerates `public/data/stars.json`:

```bash
python3 scripts/build_stars.py --mag 6.5
```
